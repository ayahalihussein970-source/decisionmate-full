import 'package:flutter/foundation.dart';

class AppState extends ChangeNotifier {
  double sleepHours = 6.0;
  int steps = 3200;
  int tasks = 4;
  String mood = 'neutral';
  int points = 0;
  List<Map<String,dynamic>> taskList = [
    {'id':1,'title':'ابدأ مشروع','done':false},
    {'id':2,'title':'مراجعة بريد','done':false},
  ];

  void setMood(String m) { mood = m; notifyListeners(); }
  void addPoints(int v){ points += v; notifyListeners(); }
  void completeTask(int id){
    final t = taskList.firstWhere((x)=>x['id']==id, orElse: ()=>null);
    if(t!=null){ t['done']=true; addPoints(10); notifyListeners(); }
  }
  void addTask(String title){ taskList.add({'id': taskList.length+1,'title':title,'done':false}); notifyListeners(); }
}
