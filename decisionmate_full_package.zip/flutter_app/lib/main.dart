import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'pages/home.dart';
import 'models/app_state.dart';

void main() {
  runApp(DecisionMateFullApp());
}

class DecisionMateFullApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState(),
      child: MaterialApp(
        title: 'Mimi Assistant - Full',
        theme: ThemeData(primarySwatch: Colors.pink),
        home: HomePage(),
      ),
    );
  }
}
