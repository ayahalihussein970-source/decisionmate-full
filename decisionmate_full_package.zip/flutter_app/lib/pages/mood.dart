import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';

class MoodPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: Text('اخبرنا عن مزاجك')),
      body: Column(children: [
        SizedBox(height:12),
        Wrap(spacing:12, children: [
          _btn(context,'happy'),
          _btn(context,'good'),
          _btn(context,'neutral'),
          _btn(context,'stressed'),
          _btn(context,'sad'),
        ])
      ]),
    );
  }
  Widget _btn(BuildContext c, String mood){
    return ElevatedButton(onPressed: (){ Provider.of<AppState>(c,listen:false).setMood(mood); Provider.of<AppState>(c,listen:false).addPoints(5); Navigator.pop(c); }, child: Text(mood));
  }
}
