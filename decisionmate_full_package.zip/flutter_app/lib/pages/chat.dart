import 'package:flutter/material.dart';

class ChatPage extends StatefulWidget {
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _ctrl = TextEditingController();
  final List<Map<String,String>> msgs = [{'from':'mimi','text':'مرحبًا! أنا Mimi، كيف أساعدك؟'}];

  void send(){ final t=_ctrl.text.trim(); if(t.isEmpty) return; setState(()=> msgs.add({'from':'user','text':t})); setState(()=> msgs.add({'from':'mimi','text': _reply(t)})); _ctrl.clear(); }
  String _reply(String t){
    final m=t.toLowerCase();
    if(m.contains('حزين')||m.contains('حزن')) return 'لا بأس، خذ نفسًا عميقًا لمرة واحدة 🌿';
    if(m.contains('متوتر')||m.contains('تعب')) return 'جرب تمارين تنفس لمدة دقيقة.';
    return 'مواء! أحسنت أنك شاركتني.';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('دردشة Mimi')), body: Column(children: [
      Expanded(child: ListView(children: msgs.map((m)=> ListTile(title: Align(alignment: m['from']=='user'?Alignment.centerRight:Alignment.centerLeft, child: Container(padding: EdgeInsets.all(8), color: m['from']=='user'?Colors.pink[100]:Colors.grey[200], child: Text(m['text']!)) ))).toList())),
      SafeArea(child: Row(children:[ Expanded(child: Padding(padding: EdgeInsets.symmetric(horizontal:8), child: TextField(controller: _ctrl))), IconButton(icon: Icon(Icons.send), onPressed: send) ]))
    ]));
  }
}
