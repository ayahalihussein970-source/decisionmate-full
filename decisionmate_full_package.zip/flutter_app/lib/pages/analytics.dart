import 'package:flutter/material.dart';

class AnalyticsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('تحليلات')), body: Center(child: Text('تحليلات أسبوعية (placeholder)')));
  }
}
