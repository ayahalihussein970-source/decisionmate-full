import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';

class StorePage extends StatelessWidget {
  final skins = [{'id':'pink','name':'Pink Mimi','price':50},{'id':'gold','name':'Golden Mimi','price':120}];
  @override
  Widget build(BuildContext context) {
    final st = Provider.of<AppState>(context);
    return Scaffold(appBar: AppBar(title: Text('المتجر')), body: ListView(children: skins.map((s)=> ListTile(title: Text(s['name']), subtitle: Text('السعر: '+s['price'].toString()+' نقطة'), trailing: ElevatedButton(onPressed: ()=> _buy(context,s), child: Text('شراء')))).toList()));
  }
  void _buy(BuildContext c, Map s){ final st = Provider.of<AppState>(c,listen:false); if(st.points >= s['price']){ st.addPoints(-s['price']); ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('تم الشراء'))); } else ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('نقود غير كافية'))); }
}
