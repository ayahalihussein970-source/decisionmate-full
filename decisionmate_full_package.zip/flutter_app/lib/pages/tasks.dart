import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';

class TasksPage extends StatelessWidget {
  final _ctrl = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: Text('مهامي')),
      body: Column(children: [
        SizedBox(height:12),
        Expanded(child: ListView(children: state.taskList.map((t)=>ListTile(
          title: Text(t['title']),
          trailing: t['done'] ? Icon(Icons.check, color: Colors.green) : ElevatedButton(onPressed: ()=> Provider.of<AppState>(context,listen:false).completeTask(t['id']), child: Text('إنهاء')),
        )).toList())),
        Padding(padding: EdgeInsets.all(8), child: Row(children:[Expanded(child: TextField(controller: _ctrl, decoration: InputDecoration(hintText:'أضف مهمة'))), ElevatedButton(onPressed: ()=> Provider.of<AppState>(context,listen:false).addTask(_ctrl.text), child: Text('إضافة'))]))
      ]),
    );
  }
}
