import 'package:flutter/material.dart';

class SettingsPage extends StatelessWidget{ Widget build(BuildContext c)=> Scaffold(appBar: AppBar(title: Text('الإعدادات')), body: Center(child: Text('Settings'))); }
