import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/app_state.dart';
import 'mood.dart';
import 'tasks.dart';
import 'chat.dart';
import 'store.dart';
import 'analytics.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final state = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Mimi Assistant')),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(height:12),
            Text('مرحبًا! حالتك: ' + state.mood, style: TextStyle(fontSize:18,fontWeight: FontWeight.bold)),
            SizedBox(height:8),
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _card('النوم', state.sleepHours.toStringAsFixed(1)+' س'),
              _card('الخطوات', state.steps.toString()),
              _card('المهام', state.tasks.toString()),
            ]),
            SizedBox(height:12),
            ElevatedButton(onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=>MoodPage())), child: Text('سجل مزاجك')),
            ElevatedButton(onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=>TasksPage())), child: Text('مهامي')),
            ElevatedButton(onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=>ChatPage())), child: Text('دردشة Mimi')),
            ElevatedButton(onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=>StorePage())), child: Text('المتجر')),
            ElevatedButton(onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=>AnalyticsPage())), child: Text('تحليلات')),
          ],
        ),
      ),
    );
  }
  Widget _card(String title, String value){
    return Card(child: Padding(padding: EdgeInsets.all(12), child: Column(children:[Text(title), SizedBox(height:6), Text(value, style: TextStyle(fontWeight: FontWeight.bold))])));
  }
}
