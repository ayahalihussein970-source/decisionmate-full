import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget{ Widget build(BuildContext c)=> Scaffold(appBar: AppBar(title: Text('الملف الشخصي')), body: Center(child: Text('Profile'))); }
