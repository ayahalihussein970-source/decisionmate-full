DecisionMate Full package

Contains a Flutter app in flutter_app/ ready to build.

To build locally:
1. Install Flutter SDK
2. cd flutter_app
3. flutter pub get
4. flutter build apk --release

Or push this repo to GitHub main branch and Actions will build an APK automatically (artifact in Actions run).
